﻿CREATE DATABASE OnlineSales;
USE OnlineSales;

CREATE TABLE KhachHang (
    MaKH INT PRIMARY KEY,
    TenKH VARCHAR(100) NOT NULL,
    DiaChi VARCHAR(255),
    NoiNhanHang VARCHAR(255),
    SoDienThoai VARCHAR(15) UNIQUE,
    Email VARCHAR(100) UNIQUE NOT NULL,
    MatKhau VARCHAR(255) NOT NULL, 
    ThoiGianTruyCapCuoi DATETIME DEFAULT NULL
);

CREATE TABLE SanPham (
    MaSP INT PRIMARY KEY,
    TenSP VARCHAR(100) NOT NULL,
    MoTa TEXT,
    Gia DECIMAL(10,2) NOT NULL
);

CREATE TABLE DonHang (
    MaDH INT PRIMARY KEY,
    MaKH INT,
    NgayDatHang DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH) ON DELETE CASCADE
);

CREATE TABLE ChiTietDonHang (
    MaDH INT,
    MaSP INT,
    SoLuong INT CHECK (SoLuong > 0),
    PRIMARY KEY (MaDH, MaSP),
    FOREIGN KEY (MaDH) REFERENCES DonHang(MaDH) ON DELETE CASCADE,
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP) ON DELETE CASCADE
);

CREATE TABLE LichSuTruyCap (
    MaKH INT,
    ThoiGian DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH) ON DELETE CASCADE
);

INSERT INTO SanPham (MaSP, TenSP, MoTa, Gia) VALUES
(1, 'Laptop Dell XPS 13', 'Laptop cao cấp của Dell', 25000000),
(2, 'iPhone 14', 'Điện thoại Apple iPhone 14', 23000000),
(3, 'Samsung Galaxy S23', 'Điện thoại Samsung cao cấp', 21000000),
(4, 'MacBook Pro 16', 'Laptop Apple mạnh mẽ', 50000000),
(5, 'Tai nghe AirPods Pro', 'Tai nghe không dây của Apple', 5500000),
(6, 'Bàn phím cơ Razer', 'Bàn phím cơ dành cho game thủ', 3000000),
(7, 'Chuột Logitech MX Master 3', 'Chuột không dây cao cấp', 2500000),
(8, 'Màn hình LG UltraFine 5K', 'Màn hình độ phân giải cao', 30000000),
(9, 'Loa Bluetooth JBL', 'Loa không dây JBL chất lượng cao', 3500000),
(10, 'Ổ cứng SSD Samsung 1TB', 'Ổ cứng tốc độ cao', 2200000);

INSERT INTO KhachHang (MaKH, TenKH, DiaChi, NoiNhanHang, SoDienThoai, Email, MatKhau) VALUES
(1, 'Nguyen Van An', 'Ha Noi', 'Cau Giay, Ha Noi', '0987654321', 'abcd@gmail.com', '12345'),
(2, 'Tran Thi Huyen', 'Ha Noi', 'Hoan Kiem, Ha Noi', '0987123456', 'huyencute@gmail.com', 'dissappered');
(3, 'Le Hoang Nam', 'Da Nang', 'Hai Chau, Da Nang', '0905123456', 'namle@gmail.com', 'password1'),
(4, 'Pham Minh Tuan', 'Ho Chi Minh', 'Quan 1, Ho Chi Minh', '0912345678', 'tuanpham@gmail.com', 'password2'),
(5, 'Hoang Thi Lan', 'Hai Phong', 'Le Chan, Hai Phong', '0988888888', 'lanhoang@gmail.com', 'password3'),
(6, 'Bui Van Hieu', 'Can Tho', 'Ninh Kieu, Can Tho', '0977777777', 'hieubui@gmail.com', 'password4'),
(7, 'Nguyen Thi Mai', 'Hue', 'Phu Nhuan, Hue', '0966666666', 'main@gmail.com', 'password5'),
(8, 'Tran Thanh Phong', 'Vung Tau', 'Ba Ria, Vung Tau', '0955555555', 'phongtran@gmail.com', 'password6'),
(9, 'Dang Kim Ngan', 'Nha Trang', 'Loc Tho, Nha Trang', '0944444444', 'ngandk@gmail.com', 'password7'),
(10, 'Vo Quoc Bao', 'Binh Duong', 'Di An, Binh Duong', '0933333333', 'baovo@gmail.com', 'password8');

INSERT INTO DonHang (MaDH, MaKH, NgayDatHang) VALUES 
(1, 1, '2025-03-01 10:15:00'), 
(2, 2, '2025-03-02 14:30:00'), 
(3, 3, '2025-03-03 09:45:00'), 
(4, 4, '2025-03-04 16:20:00'), 
(5, 5, '2025-03-05 11:10:00'), 
(6, 6, '2025-03-06 13:05:00'), 
(7, 7, '2025-03-07 15:25:00'), 
(8, 8, '2025-03-08 17:40:00'), 
(9, 9, '2025-03-09 18:50:00'), 
(10, 10, '2025-03-10 20:15:00');


INSERT INTO DonHang (MaDH, MaKH) VALUES 
(3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 8), (9, 9), (10, 10);

INSERT INTO ChiTietDonHang (MaDH, MaSP, SoLuong) VALUES
(3, 2, 1), 
(3, 4, 1),

(4, 3, 2), 
(4, 5, 1),

(5, 6, 1), 
(5, 7, 1),

(6, 8, 1),

(7, 9, 2),

(8, 10, 1), 
(8, 2, 1),

(9, 1, 3),

(10, 4, 2), 
(10, 5, 1);

UPDATE KhachHang SET ThoiGianTruyCapCuoi = GETDATE() WHERE MaKH = 1;

SELECT KH.TenKH, DH.MaDH, DH.NgayDatHang, SP.TenSP, CTDH.SoLuong, SP.Gia
FROM KhachHang KH
JOIN DonHang DH ON KH.MaKH = DH.MaKH
JOIN ChiTietDonHang CTDH ON DH.MaDH = CTDH.MaDH
JOIN SanPham SP ON CTDH.MaSP = SP.MaSP
WHERE KH.MaKH = 1;

SELECT * FROM KhachHang;
SELECT 
    MaKH AS 'Mã Khách Hàng', 
    TenKH AS 'Tên Khách Hàng', 
    DiaChi AS 'Địa Chỉ', 
    NoiNhanHang AS 'Nơi Nhận Hàng', 
    SoDienThoai AS 'Số Điện Thoại', 
    Email, 
    ThoiGianTruyCapCuoi AS 'Thời Gian Truy Cập Cuối'
FROM KhachHang;

SELECT * FROM SanPham;
SELECT * FROM DonHang;
SELECT * FROM ChiTietDonHang;
SELECT * FROM LichSuTruyCap;


